import numpy as np
import sys

arguments = sys.argv
if len(arguments)!=4:
    print("This program expects 4 arguments. Insufficient no of arguments")
    sys.exit(0)
data = np.array(np.loadtxt(arguments[1], delimiter=","))
rows, cols = np.shape(data)
labels = np.array(np.loadtxt(arguments[2], delimiter="\n"))
no_of_labels = np.shape(labels)
print(labels)